function nemoSetCpuBackend()
% nemoSetCpuBackend - specify that the CPU backend should be used
%  
% Synopsis:
%   nemoSetCpuBackend()
%  
    nemo_mex(uint32(5));
end