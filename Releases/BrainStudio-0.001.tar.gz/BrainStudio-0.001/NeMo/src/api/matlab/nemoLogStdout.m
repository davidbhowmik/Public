function nemoLogStdout()
% nemoLogStdout - Switch on logging to standard output
%  
% Synopsis:
%   nemoLogStdout()
%  
    nemo_mex(uint32(10));
end