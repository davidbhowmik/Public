#include "rtest.hpp"

int
main(int argc, char* argv[])
{
	runTorus(true);
	runKuramoto(true);
}
