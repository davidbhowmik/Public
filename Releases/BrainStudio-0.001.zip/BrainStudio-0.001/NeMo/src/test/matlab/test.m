% Run all matlab tests

fstim;
api;
regression(false, false);
regression(false, true);
vectorized;
