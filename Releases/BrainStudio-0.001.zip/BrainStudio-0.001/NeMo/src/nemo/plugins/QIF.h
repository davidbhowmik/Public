#ifndef NEMO_PLUGINS_QIF_H
#define NEMO_PLUGINS_QIF_H

/* Common symbol names for quadratic integrate-and-fire kernel */

#define PARAM_A 0

#define STATE_V 0

#endif
