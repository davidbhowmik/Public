function nemoResetConfiguration()
% nemoResetConfiguration - Replace configuration with default configuration
%  
% Synopsis:
%   nemoResetConfiguration()
%  
    nemo_mex(uint32(11));
end