function ncount = nemoNeuronCount()
% nemoNeuronCount - 
%  
% Synopsis:
%   ncount = nemoNeuronCount()
%  
% Outputs:
%   ncount  - number of neurons in the network
%    
    ncount = nemo_mex(uint32(3));
end