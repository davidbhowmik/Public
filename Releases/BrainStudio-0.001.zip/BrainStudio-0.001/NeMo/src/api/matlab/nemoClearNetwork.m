function nemoClearNetwork()
% nemoClearNetwork - clear all neurons/synapses from network
%  
% Synopsis:
%   nemoClearNetwork()
%  
    nemo_mex(uint32(4));
end