function nemoResetTimer()
% nemoResetTimer - reset both wall-clock and simulation timer
%  
% Synopsis:
%   nemoResetTimer()
%  
    nemo_mex(uint32(17));
end